
import React from 'react';

const TopBar: React.FC = () => {
  return (
    <div className="bg-gray-900 border-b border-white/5 py-2.5 font-black text-white">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-blue-400">
            <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse"></span>
            Live reporting from Western UP
          </div>
        </div>
        
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-4">
            <div className="flex gap-2.5">
              <a href="#" className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-[#1877F2] hover:text-white transition-all duration-300">
                <i className="fa-brands fa-facebook-f text-xs"></i>
              </a>
              <a href="#" className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-black hover:text-white transition-all duration-300">
                <i className="fa-brands fa-x-twitter text-xs"></i>
              </a>
              <a href="#" className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-[#CD201F] hover:text-white transition-all duration-300">
                <i className="fa-brands fa-youtube text-xs"></i>
              </a>
            </div>
          </div>
          <div className="hidden lg:block h-4 w-px bg-white/10"></div>
          <div className="hidden lg:flex items-center gap-2 text-white font-black uppercase tracking-tight text-[10px]">
            <i className="fa-regular fa-calendar text-blue-400"></i>
            <span>{new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
