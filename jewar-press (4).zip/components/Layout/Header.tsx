
import React, { useState } from 'react';
import { NewsCategory } from '../../types';
import { TOP_BAR_LINKS } from '../../constants.tsx';

interface HeaderProps {
  onCategoryChange: (cat: NewsCategory) => void;
  activeCategory: NewsCategory;
  onSignInClick: () => void;
  isLoggedIn: boolean;
}

const Header: React.FC<HeaderProps> = ({ onCategoryChange, activeCategory, onSignInClick, isLoggedIn }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Consolidated navigation items as per user request
  const navItems = [
    { id: 'live', label: 'Live', type: 'category', value: NewsCategory.LIVE },
    { id: 'videos', label: 'Videos', type: 'category', value: NewsCategory.VIDEOS },
    { id: 'advertisements', label: 'Advertisements', type: 'link', value: 'Advertisements' },
    { id: 'contact', label: 'Contact', type: 'link', value: 'Contact Us' },
    { id: 'studio', label: 'Studio', type: 'category', value: NewsCategory.STUDIO },
  ];

  const handleAction = (item: any) => {
    if (item.type === 'category') {
      onCategoryChange(item.value);
    } else {
      handleLinkClick(item.value);
    }
    setIsMobileMenuOpen(false);
  };

  const handleLinkClick = (name: string) => {
    const sectionId = name.toLowerCase().replace(' ', '-');
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      // If not on Latest page, switch and then scroll
      onCategoryChange(NewsCategory.LATEST);
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 300);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b-4 border-blue-600 shadow-md">
      {/* Top Accent Strip */}
      <div className="h-1 bg-gradient-to-r from-red-600 via-blue-600 to-red-600"></div>
      
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <button 
            className="lg:hidden text-2xl text-gray-800"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <i className={`fa-solid ${isMobileMenuOpen ? 'fa-xmark' : 'fa-bars'}`}></i>
          </button>
          
          <div 
            className="text-2xl md:text-3xl font-black tracking-tighter cursor-pointer flex items-center gap-1 group"
            onClick={() => onCategoryChange(NewsCategory.LATEST)}
          >
            <span className="bg-red-600 text-white px-2 py-0.5 rounded transform group-hover:-rotate-3 transition-transform">JEWAR</span>
            <span className="text-blue-700 uppercase">PRESS</span>
          </div>

          {/* Nav Items - Now right side of logo */}
          <nav className="hidden lg:flex items-center gap-1 border-l border-gray-100 pl-6 ml-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleAction(item)}
                className={`px-3 py-2 text-[11px] xl:text-[12px] font-black whitespace-nowrap transition-all uppercase tracking-tight relative flex items-center gap-2 rounded-lg ${
                  (item.type === 'category' && activeCategory === item.value)
                    ? 'text-white bg-blue-600' 
                    : 'text-gray-700 hover:bg-gray-100 hover:text-blue-600'
                }`}
              >
                {item.id === 'live' && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
                {item.id === 'studio' && <i className="fa-solid fa-wand-magic-sparkles text-amber-500"></i>}
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {/* Accent Badges (Promotion/Sponsors) */}
          <div className="hidden xl:flex items-center gap-1 mr-2">
            {TOP_BAR_LINKS.filter(l => l.name === 'Promotion' || l.name === 'Sponsors').map((link) => (
              <button 
                key={link.name} 
                onClick={() => handleLinkClick(link.name)}
                className={`text-[8px] font-black text-white px-2 py-1 rounded-md uppercase tracking-tighter transition-all hover:-translate-y-0.5 ${
                  link.name === 'Promotion' ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {link.name}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="hidden sm:flex relative group">
            <input 
              type="text" 
              placeholder="Search news..." 
              className="pl-9 pr-4 py-2 bg-gray-100 border border-gray-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 w-32 xl:w-44 transition-all"
            />
            <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-blue-600 text-[10px]"></i>
          </div>

          <button 
            onClick={onSignInClick}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-black transition-all text-[10px] uppercase tracking-wider ${
              isLoggedIn 
              ? 'bg-gray-100 text-gray-700' 
              : 'bg-red-600 text-white hover:bg-red-700 shadow-md shadow-red-200'
            }`}
          >
            <i className="fa-solid fa-user-circle text-sm"></i>
            {isLoggedIn ? 'Account' : 'Login'}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white fixed inset-0 top-[80px] z-40 overflow-y-auto p-6 space-y-8 shadow-2xl animate-in slide-in-from-left duration-300">
          <div className="space-y-4">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center">Main Sections</p>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleAction(item)}
                className={`block w-full text-left py-4 border-b border-gray-50 text-xl font-black flex items-center gap-3 ${
                  (item.type === 'category' && activeCategory === item.value) ? 'text-blue-600' : 'text-gray-800'
                }`}
              >
                {item.id === 'live' && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
                {item.label}
              </button>
            ))}
          </div>
          
          <div className="grid grid-cols-2 gap-3">
             {TOP_BAR_LINKS.filter(l => l.name === 'Promotion' || l.name === 'Sponsors').map((link) => (
              <button 
                key={link.name} 
                onClick={() => handleLinkClick(link.name)}
                className={`text-center py-4 rounded-xl text-white font-black text-xs uppercase ${
                   link.name === 'Promotion' ? 'bg-red-600' : 'bg-blue-600'
                }`}
              >
                {link.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
