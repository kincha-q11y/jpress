
import React from 'react';

interface NewsTickerProps {
  headlines: string[];
}

const NewsTicker: React.FC<NewsTickerProps> = ({ headlines }) => {
  return (
    <div className="bg-blue-900 text-white py-2 flex items-center overflow-hidden h-10 border-b border-white/10 shadow-lg">
      <div className="bg-red-600 px-6 py-1 font-black text-[11px] z-10 whitespace-nowrap flex items-center h-full skew-x-[-15deg] ml-[-10px] relative">
        <span className="skew-x-[15deg]">BREAKING NEWS</span>
      </div>
      <div className="news-ticker flex-1 relative h-full flex items-center">
        <div className="news-ticker-content whitespace-nowrap">
          {headlines.map((headline, idx) => (
            <span key={idx} className="mx-8 font-black text-xs flex items-center uppercase tracking-tight">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full inline-block mr-3 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>
              {headline}
            </span>
          ))}
          {headlines.map((headline, idx) => (
            <span key={`dup-${idx}`} className="mx-8 font-black text-xs flex items-center uppercase tracking-tight">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full inline-block mr-3 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>
              {headline}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NewsTicker;
