
import React from 'react';

const LiveTV: React.FC = () => {
  const handleLiveClick = () => {
    window.open('https://youtube.com/@jewarpress?si=PKqb0VhTCDor1vn7', '_blank');
  };

  return (
    <div className="bg-gray-900 text-white rounded-xl overflow-hidden shadow-2xl">
      <div className="aspect-video relative bg-black group cursor-pointer" onClick={handleLiveClick}>
        <img 
          src="https://img.youtube.com/vi/ZxSikwqNa6o/maxresdefault.jpg" 
          alt="Jewar Press Live" 
          className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <button className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center text-white text-3xl hover:scale-110 transition-transform shadow-[0_0_30px_rgba(220,38,38,0.5)] group-hover:bg-red-500">
            <i className="fa-solid fa-play ml-1"></i>
          </button>
        </div>
        <div className="absolute top-6 left-6 flex gap-3">
          <span className="bg-red-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest animate-pulse shadow-lg shadow-red-600/50">
            LIVE BROADCAST
          </span>
          <span className="bg-black/50 backdrop-blur-md px-4 py-1.5 rounded-full text-xs font-bold border border-white/10">
            Jewar & Greater Noida News
          </span>
        </div>
        <div className="absolute bottom-6 left-6 right-6">
          <div className="bg-black/40 backdrop-blur-sm p-4 rounded-xl border border-white/10">
             <h3 className="text-xl md:text-3xl font-black line-clamp-2 uppercase tracking-tighter italic">
               JEWAR PRESS: जेवर एयरपोर्ट और क्षेत्र की सभी बड़ी खबरें सबसे पहले
             </h3>
          </div>
        </div>
      </div>
      <div className="p-5 grid grid-cols-2 md:grid-cols-4 gap-6 bg-gray-800/50 backdrop-blur-md">
        <div className="border-r border-white/5">
          <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-1">Channel</p>
          <p className="font-bold text-sm text-red-500">@jewarpress</p>
        </div>
        <div className="border-r border-white/5">
          <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-1">Region</p>
          <p className="font-bold text-sm">Western UP</p>
        </div>
        <div className="border-r border-white/5">
          <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-1">Status</p>
          <p className="font-bold text-sm flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span> 24/7 Stream
          </p>
        </div>
        <div className="flex items-center justify-end gap-5 text-gray-400">
          <button onClick={handleLiveClick} className="bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-red-700 transition-colors uppercase">
            Subscribe Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default LiveTV;
