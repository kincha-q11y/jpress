
import React from 'react';
import { NewsItem } from '../../types.ts';

interface NewsGridProps {
  news: NewsItem[];
  onSummaryClick: (title: string) => void;
}

const NewsGrid: React.FC<NewsGridProps> = ({ news, onSummaryClick }) => {
  const mainStory = news[0];
  const sideStories = news.slice(1, 5);

  const handleStoryClick = (url?: string) => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div 
        className="lg:col-span-8 group cursor-pointer"
        onClick={() => handleStoryClick(mainStory.url)}
      >
        <div className="relative overflow-hidden rounded-xl h-[300px] md:h-[450px]">
          <img 
            src={mainStory.image} 
            alt={mainStory.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-6">
            <span className="bg-red-600 text-white text-xs font-bold px-3 py-1 rounded w-fit mb-3 uppercase tracking-widest flex items-center gap-2">
              <i className="fa-solid fa-play-circle animate-pulse"></i> {mainStory.category}
            </span>
            <h2 className="text-2xl md:text-4xl font-extrabold text-white mb-2 leading-tight">
              {mainStory.title}
            </h2>
            <p className="text-gray-300 line-clamp-2 mb-4 text-sm md:text-base font-medium">
              {mainStory.description}
            </p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 text-xs text-gray-400 font-bold">
                <span className="text-red-500">JEWAR PRESS</span>
                <span className="flex items-center gap-1">
                  <i className="fa-regular fa-clock"></i> {mainStory.timestamp}
                </span>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onSummaryClick(mainStory.title);
                }}
                className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-full text-xs font-bold border border-white/20 flex items-center gap-2"
              >
                <i className="fa-solid fa-bolt text-yellow-400"></i> AI SUMMARY
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-4 space-y-6">
        {sideStories.map((story) => (
          <div 
            key={story.id} 
            className="flex gap-4 group cursor-pointer border-b border-gray-100 pb-4 last:border-0"
            onClick={() => handleStoryClick(story.url)}
          >
            <div className="w-1/3 h-24 rounded-lg overflow-hidden shrink-0 relative">
              <img 
                src={story.image} 
                alt={story.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <i className="fa-solid fa-play text-white text-lg"></i>
              </div>
            </div>
            <div className="flex-1">
              <span className="text-red-600 text-[10px] font-bold uppercase tracking-wider mb-1 block">
                {story.category}
              </span>
              <h3 className="font-bold text-sm leading-snug group-hover:text-red-600 transition-colors line-clamp-3">
                {story.title}
              </h3>
              <div className="text-[10px] text-gray-400 mt-2 font-medium">
                WATCH ON YOUTUBE • {story.timestamp}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NewsGrid;
