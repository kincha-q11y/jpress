
import React, { useState, useEffect } from 'react';

const AD_IMAGES = [
  "https://i.postimg.cc/rpSjmqwj/Airtel-superfast-Wi-Fi-offer.png",
  "https://i.postimg.cc/HsVtMwLJ/Gemini-Generated-Image-ge19nige19nige19.png",
  "https://i.postimg.cc/YCFfntYL/Chat-GPT-Image-Feb-18-2026-10-47-01-AM.png"
];

const SHOW_DURATION = 5000; // 5 seconds
const GAP_DURATION = 10000; // 10 seconds

const AdPopup: React.FC = () => {
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Fixed: Use ReturnType<typeof setTimeout> instead of NodeJS.Timeout to resolve the namespace error in browser-only environments.
    let timeout: ReturnType<typeof setTimeout>;

    const startAdCycle = () => {
      // Start the gap timer
      timeout = setTimeout(() => {
        setIsVisible(true);
        
        // Start the visibility timer
        timeout = setTimeout(() => {
          setIsVisible(false);
          setCurrentAdIndex((prev) => (prev + 1) % AD_IMAGES.length);
          startAdCycle(); // Recursively start the next gap
        }, SHOW_DURATION);
      }, GAP_DURATION);
    };

    startAdCycle();

    return () => clearTimeout(timeout);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    // When manually closed, we still want to wait the full gap before next ad
    // But since the loop is running via the useEffect timers, we just hide it.
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={handleClose}></div>
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-[90vw] md:max-w-lg w-full overflow-hidden animate-in zoom-in duration-500 border border-gray-200">
        {/* Ad Header */}
        <div className="absolute top-0 left-0 right-0 p-3 flex justify-between items-center z-10 pointer-events-none">
          <div className="bg-black/60 backdrop-blur-md text-white text-[9px] font-black px-2 py-1 rounded flex items-center gap-1.5 uppercase tracking-widest border border-white/10">
            <i className="fa-solid fa-circle-info text-blue-400"></i> Sponsored
          </div>
          <button 
            onClick={handleClose}
            className="pointer-events-auto bg-black/60 backdrop-blur-md text-white w-8 h-8 rounded-full flex items-center justify-center hover:bg-black transition-colors"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Ad Image Content */}
        <div className="aspect-[4/5] md:aspect-square bg-gray-100 relative group cursor-pointer" onClick={() => window.open('#', '_blank')}>
          <img 
            src={AD_IMAGES[currentAdIndex]} 
            alt={`Advertisement ${currentAdIndex + 1}`}
            className="w-full h-full object-cover transition-transform duration-[5s] scale-100 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
             <button className="bg-blue-600 text-white w-full py-3 rounded-xl font-black uppercase tracking-widest text-xs shadow-xl">
               Learn More
             </button>
          </div>
        </div>

        {/* Google Ad style info footer */}
        <div className="p-3 bg-white flex items-center justify-between border-t border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-[10px] text-white">
              <i className="fa-solid fa-ad"></i>
            </div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight">Advertisement</p>
          </div>
          <div className="flex gap-3">
             <i className="fa-solid fa-ellipsis-vertical text-gray-300 text-xs"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdPopup;
