
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';

const VideoStudio: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationMessage, setGenerationMessage] = useState('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    // Check for API key (Mandatory for Veo)
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      setError("To use the AI Studio, you must select a paid API key with billing enabled.");
      return;
    }

    setIsGenerating(true);
    setError(null);
    setGeneratedVideoUrl(null);

    const messages = [
      "Connecting to Jewar Press AI Cluster...",
      "Analyzing news context...",
      "Synthesizing high-resolution frames...",
      "Rendering cinematic environment...",
      "Finalizing broadcast-quality output..."
    ];

    let msgIdx = 0;
    const interval = setInterval(() => {
      setGenerationMessage(messages[msgIdx % messages.length]);
      msgIdx++;
    }, 4000);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: `Jewar Press News Report: ${prompt}. Professional cinematography, 4k, broadcast lighting.`,
        config: {
          numberOfVideos: 1,
          resolution: resolution,
          aspectRatio: aspectRatio
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai as any).operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        setGeneratedVideoUrl(url);
      }
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setError("API Key issue. Please re-select your key in the dialog.");
        await (window as any).aistudio.openSelectKey();
      } else {
        setError("Generation failed. Please check your billing status or try a different prompt.");
      }
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
      setGenerationMessage('');
    }
  };

  const openKeyPicker = async () => {
    await (window as any).aistudio.openSelectKey();
    setError(null);
  };

  return (
    <div className="bg-gray-900 rounded-3xl overflow-hidden shadow-2xl border border-gray-800">
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[600px]">
        {/* Controls Sidebar */}
        <div className="lg:col-span-4 bg-gray-900 p-8 border-r border-gray-800 space-y-8">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-tighter mb-1">
              AI Creator <span className="text-red-600">Studio</span>
            </h3>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Powered by Google Veo</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Scene Description</label>
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe the news event you want to visualize..."
                className="w-full h-32 bg-gray-800 border border-gray-700 rounded-xl p-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Aspect Ratio</label>
                <select 
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2.5 text-white text-xs font-bold focus:outline-none"
                >
                  <option value="16:9">Landscape (TV)</option>
                  <option value="9:16">Portrait (Shorts)</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Quality</label>
                <select 
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as any)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-2.5 text-white text-xs font-bold focus:outline-none"
                >
                  <option value="720p">HD (720p)</option>
                  <option value="1080p">Full HD (1080p)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="pt-4">
            <button 
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className={`w-full py-4 rounded-xl font-black uppercase tracking-widest text-sm transition-all shadow-lg flex items-center justify-center gap-3 ${
                isGenerating || !prompt 
                ? 'bg-gray-800 text-gray-600 cursor-not-allowed' 
                : 'bg-red-600 text-white hover:bg-red-700 hover:shadow-red-600/20'
              }`}
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Processing...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-clapperboard"></i>
                  Generate News Clip
                </>
              )}
            </button>
          </div>

          {error && (
            <div className="p-4 bg-red-900/20 border border-red-900/50 rounded-xl">
              <p className="text-red-400 text-xs font-bold mb-3">{error}</p>
              <button 
                onClick={openKeyPicker}
                className="text-[10px] font-black text-white bg-red-600 px-3 py-1.5 rounded uppercase hover:bg-red-700 transition-colors"
              >
                Select Paid API Key
              </button>
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                className="block mt-2 text-[9px] text-gray-500 hover:underline"
              >
                Learn about billing setup
              </a>
            </div>
          )}
        </div>

        {/* Preview Area */}
        <div className="lg:col-span-8 bg-black relative flex items-center justify-center p-8">
          {isGenerating ? (
            <div className="text-center space-y-6">
              <div className="relative inline-block">
                <div className="w-24 h-24 border-4 border-red-600/20 border-t-red-600 rounded-full animate-spin"></div>
                <i className="fa-solid fa-robot absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-3xl text-red-600"></i>
              </div>
              <div>
                <h4 className="text-white font-black uppercase tracking-widest text-lg mb-2">{generationMessage}</h4>
                <p className="text-gray-500 text-xs font-bold">This typically takes 2-4 minutes...</p>
              </div>
            </div>
          ) : generatedVideoUrl ? (
            <div className="w-full h-full flex flex-col items-center justify-center space-y-6 animate-in fade-in zoom-in duration-500">
               <div className={`relative bg-gray-900 rounded-2xl overflow-hidden shadow-2xl border border-white/5 ${aspectRatio === '9:16' ? 'max-w-[300px]' : 'w-full'}`}>
                 <video 
                   src={generatedVideoUrl} 
                   controls 
                   autoPlay 
                   loop 
                   className="w-full h-auto"
                 />
                 <div className="absolute top-4 left-4 bg-red-600 text-white text-[10px] font-black px-2 py-1 rounded-full uppercase">
                   AI Generated Output
                 </div>
               </div>
               <div className="flex gap-4">
                 <a 
                   href={generatedVideoUrl} 
                   download="jewar-press-news-clip.mp4"
                   className="px-6 py-3 bg-white text-black font-black rounded-xl text-xs uppercase hover:bg-gray-200 transition-all flex items-center gap-2"
                 >
                   <i className="fa-solid fa-download"></i> Save Video
                 </a>
                 <button 
                   onClick={() => setGeneratedVideoUrl(null)}
                   className="px-6 py-3 bg-gray-800 text-white font-black rounded-xl text-xs uppercase hover:bg-gray-700 transition-all"
                 >
                   Clear Workspace
                 </button>
               </div>
            </div>
          ) : (
            <div className="text-center text-gray-700 max-w-sm">
              <div className="w-20 h-20 bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-gray-800">
                <i className="fa-solid fa-photo-film text-3xl"></i>
              </div>
              <h4 className="text-white font-black uppercase tracking-tighter mb-2">Video Preview Area</h4>
              <p className="text-sm font-medium">Configure your news report on the left and click generate to visualize your story.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoStudio;
