
import { GoogleGenAI, Type } from "@google/genai";

export const getNewsSummary = async (topic: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a professional news summary for the topic: "${topic}". Format it as a news bulletin.`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};

export const generateBreakingHeadline = async () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate 5 current breaking news headlines across India, World, Tech, and Sports. Return as JSON array of strings.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        },
        tools: [{ googleSearch: {} }]
      }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    return ["Jewar Airport expansion update", "Global markets hit record highs", "New tech policy announced"];
  }
};
